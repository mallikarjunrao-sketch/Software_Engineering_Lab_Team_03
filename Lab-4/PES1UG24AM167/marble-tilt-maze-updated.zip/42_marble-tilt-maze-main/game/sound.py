import array
import math

import pygame

SAMPLE_RATE = 22050


def _tone(notes, volume=0.4):
    """Build a mono 16-bit sound from [(frequency_hz, seconds), ...]."""
    samples = array.array("h")
    for freq, seconds in notes:
        n = int(SAMPLE_RATE * seconds)
        for i in range(n):
            envelope = 1.0 - i / n  # fade out so notes don't click
            value = math.sin(2 * math.pi * freq * i / SAMPLE_RATE)
            samples.append(int(value * envelope * volume * 32767))
    return pygame.mixer.Sound(buffer=samples.tobytes())


class SoundManager:
    """Generates and plays simple sound effects (no audio files needed).

    If audio cannot be initialised (no sound device), every method becomes
    a silent no-op so the game still runs.
    """

    BOUNCE_COOLDOWN_MS = 80
    MIN_BOUNCE_SPEED = 1.0

    def __init__(self):
        self.enabled = False
        self._last_bounce = 0
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=SAMPLE_RATE, size=-16, channels=1)
            self.bounce = _tone([(220, 0.07)], volume=0.35)
            self.goal = _tone([(523, 0.12), (659, 0.12), (784, 0.25)])
            self.timeout = _tone([(392, 0.2), (330, 0.2), (262, 0.4)])
            self.enabled = True
        except (pygame.error, NotImplementedError):
            pass

    def play_bounce(self, impact_speed):
        if not self.enabled or impact_speed < self.MIN_BOUNCE_SPEED:
            return
        now = pygame.time.get_ticks()
        if now - self._last_bounce < self.BOUNCE_COOLDOWN_MS:
            return
        self._last_bounce = now
        self.bounce.set_volume(min(1.0, impact_speed / 6))
        self.bounce.play()

    def play_goal(self):
        if self.enabled:
            self.goal.play()

    def play_timeout(self):
        if self.enabled:
            self.timeout.play()

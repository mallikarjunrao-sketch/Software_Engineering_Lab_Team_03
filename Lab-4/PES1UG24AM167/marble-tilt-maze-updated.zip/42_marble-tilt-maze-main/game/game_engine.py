import pygame
from .marble import Marble
from .wall import Wall
from .sound import SoundManager

# Game Engine

WHITE = (255, 255, 255)
DARK = (40, 40, 50)
WALL_COLOR = (90, 90, 110)
GOAL_COLOR = (60, 200, 120)

# Difficulty presets: tilt strength, friction, time limit (ms)
DIFFICULTIES = {
    "Easy":   {"tilt_strength": 0.5, "friction": 0.04,  "time_limit_ms": 60000},
    "Medium": {"tilt_strength": 0.6, "friction": 0.02,  "time_limit_ms": 45000},
    "Hard":   {"tilt_strength": 0.8, "friction": 0.008, "time_limit_ms": 30000},
}
DIFFICULTY_KEYS = {pygame.K_1: "Easy", pygame.K_2: "Medium", pygame.K_3: "Hard"}


class GameEngine:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        self.max_speed = 9
        self.walls = self._build_maze()
        self.goal_x, self.goal_y, self.goal_radius = width - 60, height - 60, 22

        self.font = pygame.font.SysFont("Arial", 26)
        self.big_font = pygame.font.SysFont("Arial", 54, bold=True)
        self.quit_requested = False
        self.sound = SoundManager()

        self.start_round("Medium")

    def start_round(self, difficulty):
        """(Re)start a round with the chosen difficulty preset."""
        self.difficulty = difficulty
        settings = DIFFICULTIES[difficulty]
        self.tilt_strength = settings["tilt_strength"]
        self.friction = settings["friction"]
        self.time_limit_ms = settings["time_limit_ms"]

        self.marble = Marble(50, 50)
        self.start_ticks = pygame.time.get_ticks()
        self.game_over = False
        self.result = None  # "solved" or "timeout"
        self.finish_time_ms = None
        self.end_ticks = None

    def _build_maze(self):
        walls = []
        t = 16  # wall thickness

        # outer boundary
        walls.append(Wall(0, 0, self.width, t))
        walls.append(Wall(0, self.height - t, self.width, t))
        walls.append(Wall(0, 0, t, self.height))
        walls.append(Wall(self.width - t, 0, t, self.height))

        # a few internal walls forming a simple winding path
        walls.append(Wall(0, 140, self.width - 140, t))
        walls.append(Wall(140, 260, self.width - 140, t))
        walls.append(Wall(0, 380, self.width - 140, t))

        return walls

    def handle_event(self, event):
        # Gameplay is driven by the mouse position (handle_input); events
        # are only needed for the end screen.
        if self.game_over and event.type == pygame.KEYDOWN:
            if event.key in DIFFICULTY_KEYS:
                self.start_round(DIFFICULTY_KEYS[event.key])
            elif event.key in (pygame.K_ESCAPE, pygame.K_q):
                self.quit_requested = True

    def handle_input(self):
        if self.game_over:
            return

        mouse_x, mouse_y = pygame.mouse.get_pos()
        dx = mouse_x - self.width // 2
        dy = mouse_y - self.height // 2
        dist = max(1, (dx ** 2 + dy ** 2) ** 0.5)
        ax = (dx / dist) * self.tilt_strength
        ay = (dy / dist) * self.tilt_strength
        self.marble.vx += ax
        self.marble.vy += ay

    def update(self):
        if self.game_over:
            return

        elapsed = pygame.time.get_ticks() - self.start_ticks
        if elapsed >= self.time_limit_ms:
            self.game_over = True
            self.result = "timeout"
            self.end_ticks = pygame.time.get_ticks()
            self.sound.play_timeout()
            return

        self.marble.vx *= (1 - self.friction)
        self.marble.vy *= (1 - self.friction)

        speed = (self.marble.vx ** 2 + self.marble.vy ** 2) ** 0.5
        if speed > self.max_speed:
            scale = self.max_speed / speed
            self.marble.vx *= scale
            self.marble.vy *= scale

        self.marble.x += self.marble.vx
        self.marble.y += self.marble.vy

        self._resolve_wall_collisions()

        gx = self.goal_x - self.marble.x
        gy = self.goal_y - self.marble.y
        if (gx ** 2 + gy ** 2) ** 0.5 <= self.goal_radius:
            self.game_over = True
            self.result = "solved"
            self.finish_time_ms = elapsed
            self.end_ticks = pygame.time.get_ticks()
            self.sound.play_goal()

    def _resolve_wall_collisions(self):
        """True circle-vs-rectangle collision.

        For each wall, find the point on the rectangle closest to the
        marble's centre. The marble only touches the wall if that point
        is closer than the marble's radius, so corners no longer cause
        phantom bounces off empty space.
        """
        m = self.marble
        for wall in self.walls:
            rect = wall.rect()

            # Closest point on the wall rectangle to the marble centre
            cx = max(rect.left, min(m.x, rect.right))
            cy = max(rect.top, min(m.y, rect.bottom))

            dx = m.x - cx
            dy = m.y - cy
            dist_sq = dx * dx + dy * dy

            if dist_sq >= m.radius * m.radius:
                continue  # not touching

            if dist_sq > 0:
                # Centre is outside the wall: push out along the contact normal
                dist = dist_sq ** 0.5
                nx, ny = dx / dist, dy / dist
                penetration = m.radius - dist
            else:
                # Centre is inside the wall: push out along the shallowest axis
                left = m.x - rect.left
                right = rect.right - m.x
                top = m.y - rect.top
                bottom = rect.bottom - m.y
                smallest = min(left, right, top, bottom)
                if smallest == left:
                    nx, ny, penetration = -1, 0, left + m.radius
                elif smallest == right:
                    nx, ny, penetration = 1, 0, right + m.radius
                elif smallest == top:
                    nx, ny, penetration = 0, -1, top + m.radius
                else:
                    nx, ny, penetration = 0, 1, bottom + m.radius

            # Separate the marble from the wall
            m.x += nx * penetration
            m.y += ny * penetration

            # Bounce: only reflect the velocity component moving into the wall
            vn = m.vx * nx + m.vy * ny
            if vn < 0:
                self.sound.play_bounce(-vn)
                m.vx -= (1 + 0.3) * vn * nx
                m.vy -= (1 + 0.3) * vn * ny

    def render(self, screen):
        screen.fill(DARK)

        for wall in self.walls:
            pygame.draw.rect(screen, WALL_COLOR, wall.rect())

        pygame.draw.circle(screen, GOAL_COLOR, (self.goal_x, self.goal_y), self.goal_radius)
        pygame.draw.circle(screen, WHITE, (int(self.marble.x), int(self.marble.y)), self.marble.radius)

        now = self.end_ticks if self.game_over else pygame.time.get_ticks()
        elapsed = now - self.start_ticks
        seconds_left = max(0, (self.time_limit_ms - elapsed) // 1000)
        timer_text = self.font.render(f"Time: {seconds_left}s", True, WHITE)
        screen.blit(timer_text, (10, 10))
        level_text = self.font.render(self.difficulty, True, WHITE)
        screen.blit(level_text, (self.width - level_text.get_width() - 24, 20))

        if self.game_over:
            self._render_end_screen(screen)

    def _render_end_screen(self, screen):
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        screen.blit(overlay, (0, 0))

        if self.result == "solved":
            title, color = "Maze Solved!", GOAL_COLOR
            detail = f"Finish time: {self.finish_time_ms / 1000:.1f}s"
        else:
            title, color = "Time's Up!", (230, 90, 90)
            detail = "The maze was not solved in time."

        lines = [
            (self.big_font, title, color, -60),
            (self.font, detail, WHITE, 0),
            (self.font, "Play again:  1 Easy   2 Medium   3 Hard", WHITE, 60),
            (self.font, "Press Esc or Q to exit", WHITE, 100),
        ]
        for font, text, col, offset in lines:
            surf = font.render(text, True, col)
            rect = surf.get_rect(center=(self.width // 2, self.height // 2 + offset))
            screen.blit(surf, rect)
